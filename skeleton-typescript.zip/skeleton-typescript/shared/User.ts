/*
Remember to share the interface between your mongoose models
and frontend here.
*/
import { User } from "../server/models/User";

export default User;
